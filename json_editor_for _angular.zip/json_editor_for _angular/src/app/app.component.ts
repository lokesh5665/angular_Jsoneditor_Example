import { Component,OnInit } from '@angular/core';
import * as JSONEditor from 'jsoneditor'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  title = 'my-dream-app';
  constructor(){

  }
  ngOnInit(){
    console.log("jsonEditor",JSONEditor);
    const container = document.getElementById("jsoneditor")
        const options = {
          mode: 'view',
          modes: ['code', 'form', 'text', 'tree', 'view', 'preview'],
          
        }
        const editor = new JSONEditor(container, options);
 
        // set json
        const initialJson = {
            "Array": [1, 2, 3],
            "Boolean": true,
            "Null": null,
            "Number": 123,
            "Object": {"a": "b", "c": "d"},
            "String": "Hello World"
        }
        editor.set(initialJson)
 
        // get json
        const updatedJson = editor.get()
  }

}
